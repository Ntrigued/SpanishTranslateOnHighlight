(async () => {
    const utils_src = chrome.extension.getURL('library/utils.js');
    const utils = await import(utils_src);

    const openai_src = chrome.extension.getURL('library/openai.js');
    const openai_lib = await import(openai_src);

    const view_src = chrome.extension.getURL('library/view.js');
    view = await import(view_src);

    const openai = await openai_lib.construct_OpenAI();

    const debounced_func = utils.debounce(async () => {
        const selected_text = document.getSelection().toString();
        if(selected_text.trim() !== "") {
            const text_length = selected_text.trim().length;
            if(text_length > 250) {
                console.log("Highlighted text is too long for translation. It cannot be more than 250 characters but is " + 
                    text_length.toString() + " characters");
            } else {
                const is_spanish = await openai.is_spanish(selected_text);
                if (is_spanish) {
                    console.clear();
                    const translation_info = await openai.get_translation_info(selected_text);
                    view.display_translation_info(selected_text, translation_info['translations'][0]);
                } else {
                    console.log("Highlighted text is not recognized as Spanish: " + selected_text);
                }
            }
        }
    });

    document.addEventListener("selectionchange", debounced_func);
})()

